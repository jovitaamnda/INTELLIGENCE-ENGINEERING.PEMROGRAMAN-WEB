<?php

namespace App\Exceptions;

use Exception;

class AcunetixApiException extends Exception
{
    // Anda bisa menambahkan fungsi khusus untuk exception ini jika diperlukan
}
