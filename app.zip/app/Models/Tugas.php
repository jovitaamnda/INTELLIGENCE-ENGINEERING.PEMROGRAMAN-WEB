<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tugas extends Model
{
    use HasFactory;

    protected $fillable = [
        'nama_tugas',
        'deskripsi_tugas',
        'deadline_tugas',
        'status_tugas',
        'id_proyek',
        'nama_proyek',
        'prioritas_tugas',
        'tanggal_mulai',
        'penanggung_jawab',
        'tim_pelaksana',
        'sumber_data',
        'tujuan_analisis',
        'metode_analisis',
        'alat_analisis',
        'catatan_tambahan'
    ];

    protected $casts = [
        'tim_pelaksana' => 'array',
    ];
}
