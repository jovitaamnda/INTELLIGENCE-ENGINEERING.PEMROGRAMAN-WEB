<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pekerjaan extends Model
{
    use HasFactory;

    protected $table = 'pekerjaan';

    protected $fillable = [
        'nama_pekerjaan',
        'deskripsi_pekerjaan',
        'id_tugas',
        'tanggal_mulai',
        'tanggal_selesai',
        'status_pekerjaan',
        'file_path',
        'objectives',
        'experience',
        'implementation',
        'batasan',
        'perencanaan',
    ];

    protected $casts = [
        'objectives' => 'array',
        'experience' => 'array',
        'implementation' => 'array',
        'batasan' => 'array',
        'perencanaan' => 'array',
    ];

    public function tugas()
    {
        return $this->belongsTo(Tugas::class, 'id_tugas');
    }
}
