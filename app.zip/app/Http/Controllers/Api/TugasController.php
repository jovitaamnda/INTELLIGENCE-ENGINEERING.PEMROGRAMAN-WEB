<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Tugas;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\TugasResource;

class TugasController extends Controller
{
    // Menampilkan semua tugas (mengembalikan resource collection)
    public function index()
    {
        $tugas = Tugas::all();
        return TugasResource::collection($tugas);
    }

    // Menyimpan tugas baru
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'nama_tugas' => 'required|string|max:255',
            'deskripsi_tugas' => 'required|string',
            'deadline_tugas' => 'required|date',
            'status_tugas' => 'required|string',
            'id_proyek' => 'required|string',
            'nama_proyek' => 'required|string',
            'prioritas_tugas' => 'required|string',
            'tanggal_mulai' => 'required|date',
            'penanggung_jawab' => 'required|string',
            'tim_pelaksana' => 'required|array',
            'sumber_data' => 'required|string',
            'tujuan_analisis' => 'required|string',
            'metode_analisis' => 'required|string',
            'alat_analisis' => 'required|string',
            'catatan_tambahan' => 'nullable|string'
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        $tugas = Tugas::create($request->all());

        return response()->json($tugas, 201);
    }

    // Menampilkan detail tugas
    public function show($id)
    {
        $tugas = Tugas::find($id);

        if (is_null($tugas)) {
            return response()->json(['message' => 'Tugas not found'], 404);
        }

        return new TugasResource($tugas);
    }

    // Memperbarui tugas
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'nama_tugas' => 'required|string|max:255',
            'deskripsi_tugas' => 'required|string',
            'deadline_tugas' => 'required|date',
            'status_tugas' => 'required|string',
            'id_proyek' => 'required|string',
            'nama_proyek' => 'required|string',
            'prioritas_tugas' => 'required|string',
            'tanggal_mulai' => 'required|date',
            'penanggung_jawab' => 'required|string',
            'tim_pelaksana' => 'required|array',
            'sumber_data' => 'required|string',
            'tujuan_analisis' => 'required|string',
            'metode_analisis' => 'required|string',
            'alat_analisis' => 'required|string',
            'catatan_tambahan' => 'nullable|string'
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        $tugas = Tugas::find($id);

        if (is_null($tugas)) {
            return response()->json(['message' => 'Tugas not found'], 404);
        }

        $tugas->update($request->all());

        return response()->json($tugas);
    }

    // Menghapus tugas
    public function destroy($id)
    {
        $tugas = Tugas::find($id);

        if (is_null($tugas)) {
            return response()->json(['message' => 'Tugas not found'], 404);
        }

        $tugas->delete();

        return response()->json(['message' => 'Tugas deleted successfully']);
    }
}
