<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Pekerjaan;
use App\Http\Resources\PekerjaanResource;

class PekerjaanController extends Controller
{
    // Menampilkan semua pekerjaan (mengembalikan resource collection)
    public function index()
    {
        $pekerjaan = Pekerjaan::all();
        return PekerjaanResource::collection($pekerjaan);
    }


    // Menyimpan pekerjaan baru
    public function store(Request $request)
    {
    }

    // Menampilkan detail pekerjaan
    public function show($id)
    {
    }

    // Memperbarui pekerjaan
    public function update(Request $request, $id)
    {
    }

    // Menghapus pekerjaan
    public function destroy($id)
    {
    }
}
