<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pekerjaan;
use App\Models\Tugas;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;

class PekerjaanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $token = $request->session()->get('auth_token');
        $pekerjaan = Pekerjaan::all();

        return view('pekerjaan.index', ['token' => $token, 'pekerjaan' => $pekerjaan]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $tugas = Tugas::all();

        return view('pekerjaan.create', ['tugas' => $tugas]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'nama_pekerjaan' => 'required|string|max:255',
            'deskripsi_pekerjaan' => 'required|string',
            'id_tugas' => 'required|exists:tugas,id',
            'tanggal_mulai' => 'required|date',
            'tanggal_selesai' => 'nullable|date',
            'status_pekerjaan' => 'required|string',
            'file' => 'nullable|file|mimes:pdf,doc,docx,xlsx,csv',
            'objectives' => 'nullable|array',
            'experience' => 'nullable|array',
            'implementation' => 'nullable|array',
            'batasan' => 'nullable|array',
            'perencanaan' => 'nullable|array',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        $filePath = null;
        if ($request->hasFile('file')) {
            $filePath = $request->file('file')->store('uploads', 'public');
        }

        $pekerjaan = Pekerjaan::create([
            'nama_pekerjaan' => $request->nama_pekerjaan,
            'deskripsi_pekerjaan' => $request->deskripsi_pekerjaan,
            'id_tugas' => $request->id_tugas,
            'tanggal_mulai' => $request->tanggal_mulai,
            'tanggal_selesai' => $request->tanggal_selesai,
            'status_pekerjaan' => $request->status_pekerjaan,
            'file_path' => $filePath,
            'objectives' => json_encode($request->objectives),
            'experience' => json_encode($request->experience),
            'implementation' => json_encode($request->implementation),
            'batasan' => json_encode($request->batasan),
            'perencanaan' => json_encode($request->perencanaan),
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Pekerjaan berhasil disimpan',
            'redirect' => route('pekerjaan.index')
        ]);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $pekerjaan = Pekerjaan::find($id);

        if (is_null($pekerjaan)) {
            return response()->json(['message' => 'Pekerjaan not found'], 404);
        }

        return view('pekerjaan.show', ['pekerjaan' => $pekerjaan]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $pekerjaan = Pekerjaan::find($id);
        $pekerjaan->objectives = json_decode($pekerjaan->objectives, true);
        $pekerjaan->experience = json_decode($pekerjaan->experience, true);
        $pekerjaan->implementation = json_decode($pekerjaan->implementation, true);
        $pekerjaan->batasan = json_decode($pekerjaan->batasan, true);
        $pekerjaan->perencanaan = json_decode($pekerjaan->perencanaan, true);

        $tugas = Tugas::all();

        if (is_null($pekerjaan)) {
            return response()->json(['message' => 'Pekerjaan not found'], 404);
        }

        return view('pekerjaan.edit', ['pekerjaan' => $pekerjaan, 'tugas' => $tugas]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validator = Validator::make($request->all(), [
            'nama_pekerjaan' => 'required|string|max:255',
            'deskripsi_pekerjaan' => 'required|string',
            'id_tugas' => 'required|exists:tugas,id',
            'tanggal_mulai' => 'required|date',
            'tanggal_selesai' => 'nullable|date',
            'status_pekerjaan' => 'required|string',
            'file' => 'nullable|file|mimes:pdf,doc,docx,xlsx,csv',
            'objectives' => 'nullable|array',
            'experience' => 'nullable|array',
            'implementation' => 'nullable|array',
            'batasan' => 'nullable|array',
            'perencanaan' => 'nullable|array',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        $pekerjaan = Pekerjaan::find($id);

        if (is_null($pekerjaan)) {
            return response()->json(['message' => 'Pekerjaan not found'], 404);
        }

        if ($request->hasFile('file')) {
            if ($pekerjaan->file_path) {
                Storage::disk('public')->delete($pekerjaan->file_path);
            }
            $filePath = $request->file('file')->store('uploads', 'public');
        } else {
            $filePath = $pekerjaan->file_path;
        }

        $pekerjaan->update([
            'nama_pekerjaan' => $request->nama_pekerjaan,
            'deskripsi_pekerjaan' => $request->deskripsi_pekerjaan,
            'id_tugas' => $request->id_tugas,
            'tanggal_mulai' => $request->tanggal_mulai,
            'tanggal_selesai' => $request->tanggal_selesai,
            'status_pekerjaan' => $request->status_pekerjaan,
            'file_path' => $filePath,
            'objectives' => json_encode($request->objectives),
            'experience' => json_encode($request->experience),
            'implementation' => json_encode($request->implementation),
            'batasan' => json_encode($request->batasan),
            'perencanaan' => json_encode($request->perencanaan),
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Pekerjaan berhasil diperbarui',
            'redirect' => route('pekerjaan.index')
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $pekerjaan = Pekerjaan::find($id);

        if (is_null($pekerjaan)) {
            return response()->json(['message' => 'Pekerjaan not found'], 404);
        }

        if ($pekerjaan->file_path) {
            Storage::disk('public')->delete($pekerjaan->file_path);
        }

        $pekerjaan->delete();

        return response()->json(['message' => 'Pekerjaan berhasil dihapus']);
    }

    /**
     * Request review for selected pekerjaan.
     */
    public function requestReview(Request $request)
    {
        // Validasi request
        $validator = Validator::make($request->all(), [
            'ids' => 'required|array',
            'ids.*' => 'integer|exists:pekerjaan,id'
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        // Ambil data dari database berdasarkan ID yang dikirimkan
        $pekerjaanIds = $request->input('ids');
        $pekerjaanData = Pekerjaan::whereIn('id', $pekerjaanIds)->get();

        // Format data untuk dikirim ke endpoint project management
        $dataToSend = $pekerjaanData->map(function ($pekerjaan) {
            return [
                'id' => $pekerjaan->id,
                'nama_pekerjaan' => $pekerjaan->nama_pekerjaan,
                'deskripsi_pekerjaan' => $pekerjaan->deskripsi_pekerjaan,
                'id_tugas' => $pekerjaan->id_tugas,
                'tanggal_mulai' => $pekerjaan->tanggal_mulai,
                'tanggal_selesai' => $pekerjaan->tanggal_selesai,
                'status_pekerjaan' => $pekerjaan->status_pekerjaan,
                'file_path' => $pekerjaan->file_path,
                'objectives' => json_decode($pekerjaan->objectives),
                'experience' => json_decode($pekerjaan->experience),
                'implementation' => json_decode($pekerjaan->implementation),
                'batasan' => json_decode($pekerjaan->batasan),
                'perencanaan' => json_decode($pekerjaan->perencanaan),
            ];
        });

        // Kirim data ke endpoint project management
        $response = Http::withToken(config('services.project_management.token'))
            ->post('https://project-management.requestcatcher.com/review', [
                'data' => $dataToSend
            ]);

        // Periksa respons dari endpoint project management
        if ($response->successful()) {
            return response()->json(['success' => true, 'message' => 'Review request sent successfully.']);
        } else {
            return response()->json(['success' => false, 'message' => 'Failed to send review request.'], $response->status());
        }
    }
}
