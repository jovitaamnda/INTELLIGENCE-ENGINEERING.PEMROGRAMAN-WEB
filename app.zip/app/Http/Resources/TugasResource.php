<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class TugasResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'nama_tugas' => $this->nama_tugas,
            'deskripsi_tugas' => $this->deskripsi_tugas,
            'deadline_tugas' => $this->deadline_tugas,
            'status_tugas' => $this->status_tugas,
            'id_proyek' => $this->id_proyek,
            'nama_proyek' => $this->nama_proyek,
            'prioritas_tugas' => $this->prioritas_tugas,
            'tanggal_mulai' => $this->tanggal_mulai,
            'penanggung_jawab' => $this->penanggung_jawab,
            'tim_pelaksana' => $this->tim_pelaksana,
            'sumber_data' => $this->sumber_data,
            'tujuan_analisis' => $this->tujuan_analisis,
            'metode_analisis' => $this->metode_analisis,
            'alat_analisis' => $this->alat_analisis,
            'catatan_tambahan' => $this->catatan_tambahan,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
