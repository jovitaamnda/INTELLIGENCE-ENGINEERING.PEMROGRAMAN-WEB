<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTugasTable extends Migration
{
    public function up()
    {
        Schema::create('tugas', function (Blueprint $table) {
            $table->id();
            $table->string('nama_tugas');
            $table->text('deskripsi_tugas');
            $table->date('deadline_tugas');
            $table->string('status_tugas');
            $table->string('id_proyek');
            $table->string('nama_proyek');
            $table->string('prioritas_tugas');
            $table->date('tanggal_mulai');
            $table->json('tim_pelaksana');
            $table->string('sumber_data');
            $table->text('tujuan_analisis');
            $table->text('metode_analisis');
            $table->text('alat_analisis');
            $table->text('catatan_tambahan')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('tugas');
    }
}
