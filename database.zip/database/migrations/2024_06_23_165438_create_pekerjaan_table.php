<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePekerjaanTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pekerjaan', function (Blueprint $table) {
            $table->id();
            $table->string('nama_pekerjaan');
            $table->text('deskripsi_pekerjaan');
            $table->foreignId('id_tugas')->constrained('tugas')->onDelete('cascade');
            $table->dateTime('tanggal_mulai');
            $table->dateTime('tanggal_selesai')->nullable();
            $table->string('status_pekerjaan');
            $table->string('file_path')->nullable();
            $table->json('objectives')->nullable();
            $table->json('experience')->nullable();
            $table->json('implementation')->nullable();
            $table->json('batasan')->nullable();
            $table->json('perencanaan')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pekerjaan');
    }
}
