@extends('../themes/' . $activeTheme)

@section('subhead')
    <title>SI-IE - Beranda</title>
@endsection

@section('subcontent')
    <div class="grid grid-cols-12 gap-x-6 gap-y-10">
        <div class="col-span-12">
            <div class="flex flex-col gap-y-3 md:h-10 md:flex-row md:items-center">
                <div class="text-base font-medium group-[.mode--light]:text-white">
                    Laporan Proyek dan Pekerjaan
                </div>
                <div class="flex flex-col gap-x-3 gap-y-2 sm:flex-row md:ml-auto">
                    <div class="relative">
                        <x-base.lucide
                            class="absolute inset-y-0 left-0 z-10 my-auto ml-3 h-4 w-4 stroke-[1.3] group-[.mode--light]:!text-slate-200"
                            icon="CalendarCheck2"
                        />
                        <x-base.form-select
                            class="rounded-[0.5rem] pl-9 group-[.mode--light]:!border-transparent group-[.mode--light]:!bg-white/[0.12] group-[.mode--light]:bg-chevron-white group-[.mode--light]:!text-slate-200 sm:w-44"
                        >
                            <option value="custom-date">Tanggal Khusus</option>
                            <option value="daily">Harian</option>
                            <option value="weekly">Mingguan</option>
                            <option value="monthly">Bulanan</option>
                            <option value="yearly">Tahunan</option>
                        </x-base.form-select>
                    </div>
                    <div class="relative">
                        <x-base.lucide
                            class="absolute inset-y-0 left-0 z-10 my-auto ml-3 h-4 w-4 stroke-[1.3] group-[.mode--light]:!text-slate-200"
                            icon="Calendar"
                        />
                        <x-base.litepicker
                            class="rounded-[0.5rem] pl-9 group-[.mode--light]:!border-transparent group-[.mode--light]:!bg-white/[0.12] group-[.mode--light]:!text-slate-200 sm:w-64"
                        />
                    </div>
                </div>
            </div>
            <div class="mt-3.5 grid grid-cols-12 gap-5">
                <div class="box box--stacked col-span-12 p-1 md:col-span-6 2xl:col-span-3">
                    <div
                        class="-mx-1 h-[244px] overflow-hidden [&_.tns-nav]:bottom-auto [&_.tns-nav]:ml-5 [&_.tns-nav]:mt-5 [&_.tns-nav]:w-auto [&_.tns-nav_button.tns-nav-active]:w-5 [&_.tns-nav_button.tns-nav-active]:bg-white/70 [&_.tns-nav_button]:mx-0.5 [&_.tns-nav_button]:h-2 [&_.tns-nav_button]:w-2 [&_.tns-nav_button]:bg-white/40">
                        <x-base.tiny-slider config="fade">
                            <div class="px-1">
                                <div
                                    class="relative flex h-full w-full flex-col overflow-hidden rounded-[0.5rem] bg-gradient-to-b from-theme-2/90 to-theme-1/[0.85] p-5">
                                    <x-base.lucide
                                        class="absolute right-0 top-0 -mr-5 -mt-5 h-36 w-36 rotate-[-10deg] transform fill-white/[0.03] stroke-[0.3] text-white/20"
                                        icon="Medal"
                                    />
                                    <div class="mb-9 mt-12">
                                        <div class="text-2xl font-medium leading-snug text-white">
                                            Tugas Baru
                                            <br>
                                            Ditambahkan!
                                        </div>
                                        <div class="mt-1.5 text-lg text-white/70">
                                            Lihat detail tugas terbaru.
                                        </div>
                                    </div>
                                    <a
                                        class="flex items-center font-medium text-white"
                                        href=""
                                    >
                                        Lihat sekarang
                                        <x-base.lucide
                                            class="ml-1.5 h-4 w-4"
                                            icon="MoveRight"
                                        />
                                    </a>
                                </div>
                            </div>
                            <div class="px-1">
                                <div
                                    class="relative flex h-full w-full flex-col overflow-hidden rounded-[0.5rem] bg-gradient-to-b from-theme-2/90 to-theme-1/90 p-5">
                                    <x-base.lucide
                                        class="absolute right-0 top-0 -mr-5 -mt-5 h-36 w-36 rotate-[-10deg] transform fill-white/[0.03] stroke-[0.3] text-white/20"
                                        icon="Database"
                                    />
                                    <div class="mb-9 mt-12">
                                        <div class="text-2xl font-medium leading-snug text-white">
                                            Pekerjaan Terselesaikan
                                            <br>
                                            dengan Baik
                                        </div>
                                        <div class="mt-1.5 text-lg text-white/70">
                                            Cek pekerjaan yang telah selesai.
                                        </div>
                                    </div>
                                    <a
                                        class="flex items-center font-medium text-white"
                                        href=""
                                    >
                                        Lihat sekarang
                                        <x-base.lucide
                                            class="ml-1.5 h-4 w-4"
                                            icon="ArrowRight"
                                        />
                                    </a>
                                </div>
                            </div>
                            <div class="px-1">
                                <div
                                    class="relative flex h-full w-full flex-col overflow-hidden rounded-[0.5rem] bg-gradient-to-b from-theme-2/90 to-theme-1/90 p-5">
                                    <x-base.lucide
                                        class="absolute right-0 top-0 -mr-5 -mt-5 h-36 w-36 rotate-[-10deg] transform fill-white/[0.03] stroke-[0.3] text-white/20"
                                        icon="Gauge"
                                    />
                                    <div class="mb-9 mt-12">
                                        <div class="text-2xl font-medium leading-snug text-white">
                                            Kinerja Tim
                                            <br>
                                            Meningkat
                                        </div>
                                        <div class="mt-1.5 text-lg text-white/70">
                                            Lihat laporan kinerja terbaru.
                                        </div>
                                    </div>
                                    <a
                                        class="flex items-center font-medium text-white"
                                        href=""
                                    >
                                        Lihat sekarang
                                        <x-base.lucide
                                            class="ml-1.5 h-4 w-4"
                                            icon="ArrowRight"
                                        />
                                    </a>
                                </div>
                            </div>
                        </x-base.tiny-slider>
                    </div>
                </div>
                <div class="box box--stacked col-span-12 flex flex-col p-5 md:col-span-6 2xl:col-span-3">
                    <x-base.menu class="absolute right-0 top-0 mr-5 mt-5">
                        <x-base.menu.button class="h-5 w-5 text-slate-500">
                            <x-base.lucide
                                class="h-6 w-6 fill-slate-400/70 stroke-slate-400/70"
                                icon="MoreVertical"
                            />
                        </x-base.menu.button>
                        <x-base.menu.items class="w-40">
                            <x-base.menu.item>
                                <x-base.lucide
                                    class="mr-2 h-4 w-4"
                                    icon="Copy"
                                /> Copy Link
                            </x-base.menu.item>
                            <x-base.menu.item>
                                <x-base.lucide
                                    class="mr-2 h-4 w-4"
                                    icon="Trash"
                                />
                                Delete
                            </x-base.menu.item>
                        </x-base.menu.items>
                    </x-base.menu>
                    <div class="flex items-center">
                        <div
                            class="flex h-12 w-12 items-center justify-center rounded-full border border-primary/10 bg-primary/10">
                            <x-base.lucide
                                class="h-6 w-6 fill-primary/10 text-primary"
                                icon="Database"
                            />
                        </div>
                        <div class="ml-4">
                            <div class="text-base font-medium">Jumlah Tugas</div>
                            <div class="mt-0.5 text-slate-500">Dikerjakan oleh Tim</div>
                        </div>
                    </div>
                    <div class="relative mb-6 mt-5 overflow-hidden">
                        <div
                            class="absolute inset-0 my-auto h-px whitespace-nowrap text-xs leading-[0] tracking-widest text-slate-400/60">
                            .......................................................................
                        </div>
                        <x-report-line-chart
                            class="relative z-10 -ml-1.5"
                            data-index="2"
                            data-border-color="primary"
                            data-background-color="primary/0.3"
                            height="h-[100px]"
                        />
                    </div>
                    <div class="flex flex-wrap items-center justify-center gap-x-5 gap-y-3">
                        <div class="flex items-center">
                            <div class="h-2 w-2 rounded-full bg-primary/70"></div>
                            <div class="ml-2.5">Tugas</div>
                        </div>
                        <div class="flex items-center">
                            <div class="h-2 w-2 rounded-full bg-slate-400"></div>
                            <div class="ml-2.5">Proyek</div>
                        </div>
                    </div>
                </div>
                <div class="box box--stacked col-span-12 flex flex-col p-5 md:col-span-6 2xl:col-span-3">
                    <x-base.menu class="absolute right-0 top-0 mr-5 mt-5">
                        <x-base.menu.button class="h-5 w-5 text-slate-500">
                            <x-base.lucide
                                class="h-6 w-6 fill-slate-400/70 stroke-slate-400/70"
                                icon="MoreVertical"
                            />
                        </x-base.menu.button>
                        <x-base.menu.items class="w-40">
                            <x-base.menu.item>
                                <x-base.lucide
                                    class="mr-2 h-4 w-4"
                                    icon="Copy"
                                /> Copy Link
                            </x-base.menu.item>
                            <x-base.menu.item>
                                <x-base.lucide
                                    class="mr-2 h-4 w-4"
                                    icon="Trash"
                                />
                                Delete
                            </x-base.menu.item>
                        </x-base.menu.items>
                    </x-base.menu>
                    <div class="flex items-center">
                        <div
                            class="flex h-12 w-12 items-center justify-center rounded-full border border-success/10 bg-success/10">
                            <x-base.lucide
                                class="h-6 w-6 fill-success/10 text-success"
                                icon="Files"
                            />
                        </div>
                        <div class="ml-4">
                            <div class="text-base font-medium">
                                Tugas Selesai
                            </div>
                            <div class="mt-0.5 text-slate-500">
                                Tugas yang telah diselesaikan
                            </div>
                        </div>
                    </div>
                    <div class="relative mb-6 mt-5 overflow-hidden">
                        <div
                            class="absolute inset-0 my-auto h-px whitespace-nowrap text-xs leading-[0] tracking-widest text-slate-400/60">
                            .......................................................................
                        </div>
                        <x-report-line-chart
                            class="relative z-10 -ml-1.5"
                            data-index="0"
                            data-border-color="success"
                            data-background-color="success/0.3"
                            height="h-[100px]"
                        />
                    </div>
                    <div class="flex flex-wrap items-center justify-center gap-x-5 gap-y-3">
                        <div class="flex items-center">
                            <div class="h-2 w-2 rounded-full bg-success/70"></div>
                            <div class="ml-2.5">Total Selesai</div>
                        </div>
                        <div class="flex items-center">
                            <div class="h-2 w-2 rounded-full bg-slate-400"></div>
                            <div class="ml-2.5">Status</div>
                        </div>
                    </div>
                </div>
                <div class="box box--stacked col-span-12 flex flex-col p-5 md:col-span-6 2xl:col-span-3">
                    <x-base.menu class="absolute right-0 top-0 mr-5 mt-5">
                        <x-base.menu.button class="h-5 w-5 text-slate-500">
                            <x-base.lucide
                                class="h-6 w-6 fill-slate-400/70 stroke-slate-400/70"
                                icon="MoreVertical"
                            />
                        </x-base.menu.button>
                        <x-base.menu.items class="w-40">
                            <x-base.menu.item>
                                <x-base.lucide
                                    class="mr-2 h-4 w-4"
                                    icon="Copy"
                                /> Copy Link
                            </x-base.menu.item>
                            <x-base.menu.item>
                                <x-base.lucide
                                    class="mr-2 h-4 w-4"
                                    icon="Trash"
                                />
                                Delete
                            </x-base.menu.item>
                        </x-base.menu.items>
                    </x-base.menu>
                    <div class="flex items-center">
                        <div
                            class="flex h-12 w-12 items-center justify-center rounded-full border border-primary/10 bg-primary/10">
                            <x-base.lucide
                                class="h-6 w-6 fill-primary/10 text-primary"
                                icon="Zap"
                            />
                        </div>
                        <div class="ml-4">
                            <div class="text-base font-medium">
                                Total Pekerjaan
                            </div>
                            <div class="mt-0.5 text-slate-500">Pekerjaan yang sedang berlangsung</div>
                        </div>
                    </div>
                    <div class="relative mb-6 mt-5">
                        <x-report-donut-chart-3
                            class="relative z-10"
                            height="h-[100px]"
                        />
                    </div>
                    <div class="flex flex-wrap items-center justify-center gap-x-5 gap-y-3">
                        <div class="flex items-center">
                            <div class="h-2 w-2 rounded-full bg-primary/70"></div>
                            <div class="ml-2.5">Pekerjaan</div>
                        </div>
                        <div class="flex items-center">
                            <div class="h-2 w-2 rounded-full bg-danger/70"></div>
                            <div class="ml-2.5">Status</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-span-12">
            <div class="flex flex-col gap-y-3 md:h-10 md:flex-row md:items-center">
                <div class="text-base font-medium">Insight Kinerja</div>
                <div class="flex gap-x-3 gap-y-2 md:ml-auto">
                    <x-base.button
                        class="rounded-[0.5rem] bg-white text-slate-600 dark:text-slate-300"
                        data-carousel="important-notes"
                        data-target="prev"
                    >
                        <span class="flex h-5 w-3.5 items-center justify-center">
                            <x-base.lucide
                                class="h-4 w-4"
                                icon="ChevronLeft"
                            />
                        </span>
                    </x-base.button>
                    <x-base.button
                        class="rounded-[0.5rem] bg-white text-slate-600 dark:text-slate-300"
                        data-carousel="important-notes"
                        data-target="next"
                    >
                        <span class="flex h-5 w-3.5 items-center justify-center">
                            <x-base.lucide
                                class="h-4 w-4"
                                icon="ChevronRight"
                            />
                        </span>
                    </x-base.button>
                </div>
            </div>
            <div class="-mx-2.5 mt-3.5">
                <x-base.tiny-slider config="performance-insight-slider-config">
                    <div class="px-2.5 pb-3">
                        <div class="box box--stacked relative p-5">
                            <div class="flex items-center">
                                <div class="group flex items-center justify-center w-10 h-10 border rounded-full border-primary/10 bg-primary/10">
                                    <x-base.lucide
                                        class="w-5 h-5 group-[.primary]:text-primary group-[.primary]:fill-primary/10"
                                        icon="Clipboard"
                                    />
                                </div>
                                <div class="ml-auto flex">
                                    <div class="image-fit zoom-in h-8 w-8">
                                        <img
                                            class="rounded-full shadow-[0px_0px_0px_2px_#fff,_1px_1px_5px_rgba(0,0,0,0.32)] dark:shadow-[0px_0px_0px_2px_#3f4865,_1px_1px_5px_rgba(0,0,0,0.32)]"
                                            src="https://via.placeholder.com/100"
                                            alt="Tailwise - Admin Dashboard Template"
                                        >
                                    </div>
                                    <div class="image-fit zoom-in -ml-3 h-8 w-8">
                                        <img
                                            class="rounded-full shadow-[0px_0px_0px_2px_#fff,_1px_1px_5px_rgba(0,0,0,0.32)] dark:shadow-[0px_0px_0px_2px_#3f4865,_1px_1px_5px_rgba(0,0,0,0.32)]"
                                            src="https://via.placeholder.com/100"
                                            alt="Tailwise - Admin Dashboard Template"
                                        >
                                    </div>
                                    <div class="image-fit zoom-in -ml-3 h-8 w-8">
                                        <img
                                            class="rounded-full shadow-[0px_0px_0px_2px_#fff,_1px_1px_5px_rgba(0,0,0,0.32)] dark:shadow-[0px_0px_0px_2px_#3f4865,_1px_1px_5px_rgba(0,0,0,0.32)]"
                                            src="https://via.placeholder.com/100"
                                            alt="Tailwise - Admin Dashboard Template"
                                        >
                                    </div>
                                </div>
                            </div>
                            <div class="mt-11">
                                <div class="text-base font-medium">Tugas Tim</div>
                                <div class="mt-0.5 text-slate-500">
                                    Menyelesaikan tugas dalam waktu singkat.
                                </div>
                            </div>
                            <a
                                class="mt-4 flex items-center border-t border-dashed pt-4 font-medium text-primary"
                                href=""
                            >
                                Lihat detail
                                <x-base.lucide
                                    class="ml-1.5 h-4 w-4"
                                    icon="ArrowRight"
                                />
                            </a>
                        </div>
                    </div>
                    <div class="px-2.5 pb-3">
                        <div class="box box--stacked relative p-5">
                            <div class="flex items-center">
                                <div class="group flex items-center justify-center w-10 h-10 border rounded-full border-primary/10 bg-primary/10">
                                    <x-base.lucide
                                        class="w-5 h-5 group-[.primary]:text-primary group-[.primary]:fill-primary/10"
                                        icon="Files"
                                    />
                                </div>
                                <div class="ml-auto flex">
                                    <div class="image-fit zoom-in h-8 w-8">
                                        <img
                                            class="rounded-full shadow-[0px_0px_0px_2px_#fff,_1px_1px_5px_rgba(0,0,0,0.32)] dark:shadow-[0px_0px_0px_2px_#3f4865,_1px_1px_5px_rgba(0,0,0,0.32)]"
                                            src="https://via.placeholder.com/100"
                                            alt="Tailwise - Admin Dashboard Template"
                                        >
                                    </div>
                                    <div class="image-fit zoom-in -ml-3 h-8 w-8">
                                        <img
                                            class="rounded-full shadow-[0px_0px_0px_2px_#fff,_1px_1px_5px_rgba(0,0,0,0.32)] dark:shadow-[0px_0px_0px_2px_#3f4865,_1px_1px_5px_rgba(0,0,0,0.32)]"
                                            src="https://via.placeholder.com/100"
                                            alt="Tailwise - Admin Dashboard Template"
                                        >
                                    </div>
                                    <div class="image-fit zoom-in -ml-3 h-8 w-8">
                                        <img
                                            class="rounded-full shadow-[0px_0px_0px_2px_#fff,_1px_1px_5px_rgba(0,0,0,0.32)] dark:shadow-[0px_0px_0px_2px_#3f4865,_1px_1px_5px_rgba(0,0,0,0.32)]"
                                            src="https://via.placeholder.com/100"
                                            alt="Tailwise - Admin Dashboard Template"
                                        >
                                    </div>
                                </div>
                            </div>
                            <div class="mt-11">
                                <div class="text-base font-medium">Proyek Baru</div>
                                <div class="mt-0.5 text-slate-500">
                                    Mengelola proyek dengan efisien.
                                </div>
                            </div>
                            <a
                                class="mt-4 flex items-center border-t border-dashed pt-4 font-medium text-primary"
                                href=""
                            >
                                Lihat detail
                                <x-base.lucide
                                    class="ml-1.5 h-4 w-4"
                                    icon="ArrowRight"
                                />
                            </a>
                        </div>
                    </div>
                </x-base.tiny-slider>
            </div>
        </div>
        <div class="col-span-12">
            <div class="flex flex-col gap-y-3 md:h-10 md:flex-row md:items-center">
                <div class="text-base font-medium">Tugas Terbaru</div>
                <div class="flex flex-col gap-x-3 gap-y-2 sm:flex-row md:ml-auto">
                    <div class="relative">
                        <x-base.lucide
                            class="absolute inset-y-0 left-0 z-10 my-auto ml-3 h-4 w-4 stroke-[1.3]"
                            icon="CalendarCheck2"
                        />
                        <x-base.form-select class="rounded-[0.5rem] pl-9 sm:w-44">
                            <option value="custom-date">Tanggal Khusus</option>
                            <option value="daily">Harian</option>
                            <option value="weekly">Mingguan</option>
                            <option value="monthly">Bulanan</option>
                            <option value="yearly">Tahunan</option>
                        </x-base.form-select>
                    </div>
                    <div class="relative">
                        <x-base.lucide
                            class="absolute inset-y-0 left-0 z-10 my-auto ml-3 h-4 w-4 stroke-[1.3]"
                            icon="Calendar"
                        />
                        <x-base.litepicker class="rounded-[0.5rem] pl-9 sm:w-64" />
                    </div>
                </div>
            </div>
            <div class="mt-2 overflow-auto lg:overflow-visible">
                <x-base.table class="border-separate border-spacing-y-[10px]">
                    <x-base.table.tbody>
                        <x-base.table.tr>
                            <x-base.table.td
                                class="box rounded-l-none rounded-r-none border-x-0 shadow-[5px_3px_5px_#00000005] first:rounded-l-[0.6rem] first:border-l last:rounded-r-[0.6rem] last:border-r dark:bg-darkmode-600"
                            >
                                <div class="flex items-center">
                                    <x-base.lucide
                                        class="h-6 w-6 fill-primary/10 stroke-[0.8] text-theme-1"
                                        icon="Clipboard"
                                    />
                                    <div class="ml-3.5">
                                        <a
                                            class="whitespace-nowrap font-medium"
                                            href=""
                                        >
                                            Tugas A
                                        </a>
                                        <div class="mt-1 whitespace-nowrap text-xs text-slate-500">
                                            Deskripsi tugas A
                                        </div>
                                    </div>
                                </div>
                            </x-base.table.td>
                            <x-base.table.td
                                class="box w-60 rounded-l-none rounded-r-none border-x-0 shadow-[5px_3px_5px_#00000005] first:rounded-l-[0.6rem] first:border-l last:rounded-r-[0.6rem] last:border-r dark:bg-darkmode-600"
                            >
                                <div class="mb-1 whitespace-nowrap text-xs text-slate-500">
                                    Nama Penugasan
                                </div>
                                <a
                                    class="flex items-center text-primary"
                                    href=""
                                >
                                    <x-base.lucide
                                        class="h-3.5 w-3.5 stroke-[1.7]"
                                        icon="ExternalLink"
                                    />
                                    <div class="ml-1.5 whitespace-nowrap">
                                        Penugasan 1
                                    </div>
                                </a>
                            </x-base.table.td>
                            <x-base.table.td
                                class="box w-44 rounded-l-none rounded-r-none border-x-0 shadow-[5px_3px_5px_#00000005] first:rounded-l-[0.6rem] first:border-l last:rounded-r-[0.6rem] last:border-r dark:bg-darkmode-600"
                            >
                                <div class="mb-1.5 whitespace-nowrap text-xs text-slate-500">
                                    Tanggal Mulai
                                </div>
                                <div class="mb-1">
                                    2023-06-24
                                </div>
                            </x-base.table.td>
                            <x-base.table.td
                                class="box w-44 rounded-l-none rounded-r-none border-x-0 shadow-[5px_3px_5px_#00000005] first:rounded-l-[0.6rem] first:border-l last:rounded-r-[0.6rem] last:border-r dark:bg-darkmode-600"
                            >
                                <div class="mb-1 whitespace-nowrap text-xs text-slate-500">
                                    Tanggal Selesai
                                </div>
                                <div class="whitespace-nowrap">2023-06-25</div>
                            </x-base.table.td>
                            <x-base.table.td
                                class="box relative w-20 rounded-l-none rounded-r-none border-x-0 py-0 shadow-[5px_3px_5px_#00000005] first:rounded-l-[0.6rem] first:border-l last:rounded-r-[0.6rem] last:border-r dark:bg-darkmode-600"
                            >
                                <div class="flex items-center justify-center">
                                    <x-base.menu class="h-5">
                                        <x-base.menu.button class="h-5 w-5 text-slate-500">
                                            <x-base.lucide
                                                class="h-5 w-5 fill-slate-400/70 stroke-slate-400/70"
                                                icon="MoreVertical"
                                            />
                                        </x-base.menu.button>
                                        <x-base.menu.items class="w-40">
                                            <x-base.menu.item>
                                                <x-base.lucide
                                                    class="mr-2 h-4 w-4"
                                                    icon="WalletCards"
                                                />
                                                Lihat Detail
                                            </x-base.menu.item>
                                            <x-base.menu.item>
                                                <x-base.lucide
                                                    class="mr-2 h-4 w-4"
                                                    icon="FileSignature"
                                                />
                                                Edit Tugas
                                            </x-base.menu.item>
                                            <x-base.menu.item>
                                                <x-base.lucide
                                                    class="mr-2 h-4 w-4"
                                                    icon="Printer"
                                                />
                                                Cetak
                                            </x-base.menu.item>
                                        </x-base.menu.items>
                                    </x-base.menu>
                                </div>
                            </x-base.table.td>
                        </x-base.table.tr>
                        <x-base.table.tr>
                            <x-base.table.td
                                class="box rounded-l-none rounded-r-none border-x-0 shadow-[5px_3px_5px_#00000005] first:rounded-l-[0.6rem] first:border-l last:rounded-r-[0.6rem] last:border-r dark:bg-darkmode-600"
                            >
                                <div class="flex items-center">
                                    <x-base.lucide
                                        class="h-6 w-6 fill-primary/10 stroke-[0.8] text-theme-1"
                                        icon="Clipboard"
                                    />
                                    <div class="ml-3.5">
                                        <a
                                            class="whitespace-nowrap font-medium"
                                            href=""
                                        >
                                            Tugas B
                                        </a>
                                        <div class="mt-1 whitespace-nowrap text-xs text-slate-500">
                                            Deskripsi tugas B
                                        </div>
                                    </div>
                                </div>
                            </x-base.table.td>
                            <x-base.table.td
                                class="box w-60 rounded-l-none rounded-r-none border-x-0 shadow-[5px_3px_5px_#00000005] first:rounded-l-[0.6rem] first:border-l last:rounded-r-[0.6rem] last:border-r dark:bg-darkmode-600"
                            >
                                <div class="mb-1 whitespace-nowrap text-xs text-slate-500">
                                    Nama Penugasan
                                </div>
                                <a
                                    class="flex items-center text-primary"
                                    href=""
                                >
                                    <x-base.lucide
                                        class="h-3.5 w-3.5 stroke-[1.7]"
                                        icon="ExternalLink"
                                    />
                                    <div class="ml-1.5 whitespace-nowrap">
                                        Penugasan 2
                                    </div>
                                </a>
                            </x-base.table.td>
                            <x-base.table.td
                                class="box w-44 rounded-l-none rounded-r-none border-x-0 shadow-[5px_3px_5px_#00000005] first:rounded-l-[0.6rem] first:border-l last:rounded-r-[0.6rem] last:border-r dark:bg-darkmode-600"
                            >
                                <div class="mb-1.5 whitespace-nowrap text-xs text-slate-500">
                                    Tanggal Mulai
                                </div>
                                <div class="mb-1">
                                    2023-06-26
                                </div>
                            </x-base.table.td>
                            <x-base.table.td
                                class="box w-44 rounded-l-none rounded-r-none border-x-0 shadow-[5px_3px_5px_#00000005] first:rounded-l-[0.6rem] first:border-l last:rounded-r-[0.6rem] last:border-r dark:bg-darkmode-600"
                            >
                                <div class="mb-1 whitespace-nowrap text-xs text-slate-500">
                                    Tanggal Selesai
                                </div>
                                <div class="whitespace-nowrap">2023-06-27</div>
                            </x-base.table.td>
                            <x-base.table.td
                                class="box relative w-20 rounded-l-none rounded-r-none border-x-0 py-0 shadow-[5px_3px_5px_#00000005] first:rounded-l-[0.6rem] first:border-l last:rounded-r-[0.6rem] last:border-r dark:bg-darkmode-600"
                            >
                                <div class="flex items-center justify-center">
                                    <x-base.menu class="h-5">
                                        <x-base.menu.button class="h-5 w-5 text-slate-500">
                                            <x-base.lucide
                                                class="h-5 w-5 fill-slate-400/70 stroke-slate-400/70"
                                                icon="MoreVertical"
                                            />
                                        </x-base.menu.button>
                                        <x-base.menu.items class="w-40">
                                            <x-base.menu.item>
                                                <x-base.lucide
                                                    class="mr-2 h-4 w-4"
                                                    icon="WalletCards"
                                                />
                                                Lihat Detail
                                            </x-base.menu.item>
                                            <x-base.menu.item>
                                                <x-base.lucide
                                                    class="mr-2 h-4 w-4"
                                                    icon="FileSignature"
                                                />
                                                Edit Tugas
                                            </x-base.menu.item>
                                            <x-base.menu.item>
                                                <x-base.lucide
                                                    class="mr-2 h-4 w-4"
                                                    icon="Printer"
                                                />
                                                Cetak
                                            </x-base.menu.item>
                                        </x-base.menu.items>
                                    </x-base.menu>
                                </div>
                            </x-base.table.td>
                        </x-base.table.tr>
                    </x-base.table.tbody>
                </x-base.table>
            </div>
            <div class="flex-reverse mt-3 flex flex-col-reverse flex-wrap items-center gap-y-2 sm:flex-row">
                <x-base.pagination class="mr-auto w-full flex-1 sm:w-auto">
                    <x-base.pagination.link>
                        <x-base.lucide
                            class="h-4 w-4"
                            icon="ChevronsLeft"
                        />
                    </x-base.pagination.link>
                    <x-base.pagination.link>
                        <x-base.lucide
                            class="h-4 w-4"
                            icon="ChevronLeft"
                        />
                    </x-base.pagination.link>
                    <x-base.pagination.link>...</x-base.pagination.link>
                    <x-base.pagination.link>1</x-base.pagination.link>
                    <x-base.pagination.Link active>2</x-base.pagination.link>
                    <x-base.pagination.link>3</x-base.pagination.link>
                    <x-base.pagination.link>...</x-base.pagination.link>
                    <x-base.pagination.link>
                        <x-base.lucide
                            class="h-4 w-4"
                            icon="ChevronRight"
                        />
                    </x-base.pagination.link>
                    <x-base.pagination.link>
                        <x-base.lucide
                            class="h-4 w-4"
                            icon="ChevronsRight"
                        />
                    </x-base.pagination.link>
                </x-base.pagination>
                <x-base.form-select class="rounded-[0.5rem] sm:w-20">
                    <option>10</option>
                    <option>25</option>
                    <option>35</option>
                    <option>50</option>
                </x-base.form-select>
            </div>
        </div>
    </div>
@endsection
