@extends('../themes/' . $activeTheme)

@section('subcontent')
    @include('partials.notification')
    <div class="grid grid-cols-12 gap-6 gap-y-10">
        <div class="col-span-12 sm:col-span-10 sm:col-start-2">
            <div class="flex flex-col gap-3 md:h-10 md:flex-row md:items-center">
                <div class="text-base font-medium text-white">Edit Proyek</div>
            </div>
            <div class="mt-7">
                <form id="createTargetForm" action="{{ route('projects.update', $project->project_id) }}" method="POST" class="box flex flex-col" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <div class="p-7">
                        @foreach([
                            'project_name' => 'Nama Proyek',
                            'project_goal' => 'Tujuan Proyek'
                        ] as $field => $label)
                            <div class="mt-5 flex flex-col pt-5 sm:flex-row xl:items-center">
                                <label class="mb-2 sm:mb-0 sm:mr-5 xl:mr-14 xl:w-60">
                                    <div class="font-medium">{{ $label }}</div>
                                    <div class="mt-1.5 text-xs text-slate-500/80 xl:mt-3">Diambil dari aplikasi project management.</div>
                                </label>
                                <div class="mt-3 w-full flex-1 xl:mt-0">
                                    <x-base.form-input type="text" value="{{ $project->$field }}" disabled />
                                </div>
                            </div>
                        @endforeach

                        @php
                            $fields = [
                                'benefit' => 'Manfaat Proyek',
                                'leading_indicator' => 'Indikator Utama',
                                'user_outcome_model_properties' => 'Properti Model dan Hasil Pengguna',
                                'start_date' => 'Tanggal Mulai',
                                'end_date' => 'Tanggal Selesai',
                                'notes' => 'Catatan Akhir Kegiatan',
                                'file_upload' => 'Upload File',
                                'status' => 'Status Proyek'
                            ];
                        @endphp

                        @foreach($fields as $name => $label)
                            <div class="mt-5 flex flex-col pt-5 sm:flex-row xl:items-center">
                                <label class="mb-2 sm:mb-0 sm:mr-5 xl:mr-14 xl:w-60">
                                    <div class="font-medium">{{ $label }}</div>
                                    <div class="mt-1.5 text-xs text-slate-500/80 xl:mt-3">Masukkan {{ strtolower($label) }}.</div>
                                </label>
                                <div class="mt-3 w-full flex-1 xl:mt-0">
                                    @if($name === 'start_date' || $name === 'end_date')
                                        <input type="datetime-local" name="{{ $name }}" class="form-input rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white" />
                                    @elseif($name === 'file_upload')
                                        <input type="file" name="{{ $name }}" class="form-input rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white" />
                                    @elseif($name === 'status')
                                        <x-base.tom-select class="w-full" name="status" placeholder="Pilih status">
                                            @foreach(['Belum Dimulai', 'Sedang Berjalan', 'Selesai'] as $status)
                                                <option value="{{ $status }}" {{ $project->status === $status ? 'selected' : '' }}>{{ $status }}</option>
                                            @endforeach
                                        </x-base.tom-select>
                                    @else
                                        <x-base.form-textarea name="{{ $name }}" placeholder="Masukkan {{ strtolower($label) }}">{{ $project->$name ?? '' }}</x-base.form-textarea>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                    <div class="flex border-t border-slate-200/80 px-7 py-5 md:justify-end">
                        <x-base.button type="submit" class="w-full border-primary/50 px-10 md:w-auto" variant="primary">
                            <x-base.lucide class="-ml-2 mr-2 h-4 w-4" icon="save" />
                            Simpan
                        </x-base.button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@pushOnce('scripts')
    @vite('resources/js/components/notification.js')
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const form = document.getElementById('createTargetForm');
            form.addEventListener('submit', function (event) {
                event.preventDefault();
                fetch(form.action, {
                    method: 'POST',
                    body: new FormData(form),
                })
                    .then(response => response.json())
                    .then(data => {
                        showNotification(data.status, data.message);
                        if (data.status === 'success') {
                            setTimeout(() => {
                                window.location.href = data.redirect;
                            }, 1000);
                        }
                    })
                    .catch(console.error);
            });
        });
    </script>
@endPushOnce
