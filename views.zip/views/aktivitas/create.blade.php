@extends('../themes/' . $activeTheme)

@section('subcontent')
    <div class="grid grid-cols-12 gap-x-6 gap-y-10">
        <div class="col-span-12 sm:col-span-10 sm:col-start-2">
            <div class="flex flex-col gap-y-3 md:h-10 md:flex-row md:items-center">
                <div class="text-base font-medium group-[.mode--light]:text-white">Tambah Proyek Baru</div>
            </div>
            <div class="mt-7">
                <form id="createTargetForm" action="/api/intelligence-engineering/projects" method="POST" class="box box--stacked flex flex-col" enctype="multipart/form-data">
                    @csrf
                    <div class="p-7">
                        <!-- Project Name -->
                        <div class="mt-5 block flex-col pt-5 first:mt-0 first:pt-0 sm:flex xl:flex-row xl:items-center">
                            <label class="mb-2 sm:mb-0 sm:mr-5 sm:text-right xl:mr-14 xl:w-60">
                                <div class="text-left">
                                    <div class="flex items-center">
                                        <div class="font-medium">Nama Proyek</div>
                                    </div>
                                    <div class="mt-1.5 text-xs leading-relaxed text-slate-500/80 xl:mt-3">
                                        Nama proyek diambil dari aplikasi project management.
                                    </div>
                                </div>
                            </label>
                            <div class="mt-3 w-full flex-1 xl:mt-0">
                                <x-base.form-input type="text" name="project_name" value="Ini nama proyeknya" disabled />
                            </div>
                        </div>
                        <!-- Project Goal -->
                        <div class="mt-5 block flex-col pt-5 first:mt-0 first:pt-0 sm:flex xl:flex-row xl:items-center">
                            <label class="mb-2 sm:mb-0 sm:mr-5 sm:text-right xl:mr-14 xl:w-60">
                                <div class="text-left">
                                    <div class="flex items-center">
                                        <div class="font-medium">Tujuan Proyek</div>
                                    </div>
                                    <div class="mt-1.5 text-xs leading-relaxed text-slate-500/80 xl:mt-3">
                                        Tujuan proyek diambil dari aplikasi project management.
                                    </div>
                                </div>
                            </label>
                            <div class="mt-3 w-full flex-1 xl:mt-0">
                                <x-base.form-input type="text" name="project_goal" value="Ini tujuan proyeknya" disabled />
                            </div>
                        </div>

                        <!-- Dynamic fields -->
                        @php
                            $fields = [
                                'benefit' => 'Manfaat Proyek',
                                'leading_indicator' => 'Indikator Utama',
                                'user_outcome_model_properties' => 'Properti Model dan Hasil Pengguna',
                                'start_date' => 'Tanggal Mulai',
                                'end_date' => 'Tanggal Selesai',
                                'notes' => 'Catatan Akhir Kegiatan',
                                'file_upload' => 'Upload File',
                                'status' => 'Status Proyek'
                            ];
                        @endphp

                        @foreach($fields as $name => $label)
                            <div class="mt-5 block flex-col pt-5 first:mt-0 first:pt-0 sm:flex xl:flex-row xl:items-center">
                                <label class="mb-2 sm:mb-0 sm:mr-5 sm:text-right xl:mr-14 xl:w-60">
                                    <div class="text-left">
                                        <div class="flex items-center">
                                            <div class="font-medium">{{ $label }}</div>
                                        </div>
                                        <div class="mt-1.5 text-xs leading-relaxed text-slate-500/80 xl:mt-3">
                                            Masukkan {{ strtolower($label) }}.
                                        </div>
                                    </div>
                                </label>
                                <div class="mt-3 w-full flex-1 xl:mt-0">
                                    @if($name === 'start_date' || $name === 'end_date')
                                        <input type="datetime-local" name="{{ $name }}" class="form-input rounded border border-gray-300 bg-white dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white" />
                                    @elseif($name === 'file_upload')
                                        <input type="file" name="{{ $name }}" class="form-input rounded border border-gray-300 bg-white dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white" />
                                    @elseif($name === 'status')
                                        <x-base.tom-select class="w-full" data-placeholder="Pilih status" name="status">
                                            <option value="Belum Dimulai">Belum Dimulai</option>
                                            <option value="Sedang Berjalan">Sedang Berjalan</option>
                                            <option value="Selesai">Selesai</option>
                                        </x-base.tom-select>
                                    @else
                                        <x-base.form-textarea name="{{ $name }}" placeholder="Masukkan {{ strtolower($label) }}" />
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                    <div class="flex border-t border-slate-200/80 px-7 py-5 md:justify-end">
                        <x-base.button type="submit" class="w-full border-primary/50 px-10 md:w-auto" variant="primary">
                            <x-base.lucide class="-ml-2 mr-2 h-4 w-4 stroke-[1.3]" icon="save" />
                            Simpan
                        </x-base.button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@pushOnce('scripts')
    @vite('resources/js/components/notification.js')
@endPushOnce

@pushOnce('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const form = document.getElementById('createTargetForm');
            form.addEventListener('submit', function (event) {
                event.preventDefault();

                fetch(form.action, {
                    method: 'POST',
                    body: new FormData(form),
                })
                    .then(response => response.json())
                    .then(data => {
                        showNotification(data.status, data.message);
                        if (data.status === 'success') {
                            setTimeout(() => {
                                window.location.href = data.redirect;
                            }, 1000);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            });
        });
    </script>
@endPushOnce
