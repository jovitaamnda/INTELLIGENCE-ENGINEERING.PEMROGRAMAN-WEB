<x-base.leaflet-map-loader
    lat="-6.2425342"
    long="106.8626478"
    apiKey="1e86fd5a7f60486a8e899411776f60d5"
    {{ $attributes->merge($attributes->whereDoesntStartWith('class')->getAttributes()) }}
/>
