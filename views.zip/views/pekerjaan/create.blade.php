@extends('../themes/' . $activeTheme)

@section('subcontent')
    @include('partials.notification')
    <div class="grid grid-cols-12 gap-6 gap-y-10">
        <div class="col-span-12 sm:col-span-10 sm:col-start-2">
            <div class="flex flex-col gap-3 md:h-10 md:flex-row md:items-center">
                <div class="text-base font-medium">Buat Pekerjaan</div>
            </div>
            <div class="mt-5">
                <form id="createPekerjaanForm" action="{{ route('pekerjaan.store') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="flex flex-col p-5 box box--stacked">
                        <div class="rounded-[0.6rem] border border-slate-200/60 p-5 dark:border-darkmode-400">
                            <div class="flex items-center border-b border-slate-200/60 pb-5 text-[0.94rem] font-medium dark:border-darkmode-400">Informasi Pekerjaan</div>
                            <div class="mt-5">
                                <label class="font-medium">Nama Pekerjaan</label>
                                <x-base.form-input name="nama_pekerjaan" class="form-control mt-3"/>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">Deskripsi Pekerjaan</label>
                                <x-base.form-textarea name="deskripsi_pekerjaan" class="form-control mt-3"/>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">ID Tugas</label>
                                <x-base.tom-select class="w-full" data-placeholder="Pilih ID Tugas" name="id_tugas" class="form-control mt-3">
                                    <option value="" disabled selected>Pilih ID Tugas</option>
                                    @foreach ($tugas as $tugasItem)
                                        <option value="{{ $tugasItem->id }}">{{ $tugasItem->id }} - {{ $tugasItem->nama_tugas }}</option>
                                    @endforeach
                                </x-base.tom-select>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">Tanggal Mulai</label>
                                <x-base.form-input type="datetime-local" name="tanggal_mulai" class="form-control mt-3"/>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">Tanggal Selesai</label>
                                <x-base.form-input type="datetime-local" name="tanggal_selesai" class="form-control mt-3"/>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">Status Pekerjaan</label>
                                <x-base.tom-select class="w-full" data-placeholder="Pilih Status Pekerjaan" name="status_pekerjaan" class="form-control mt-3" required>
                                    <option value="" disabled selected>Pilih Status Pekerjaan</option>
                                    <option value="Dalam Proses">Dalam Proses</option>
                                    <option value="Selesai">Selesai</option>
                                </x-base.tom-select>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">Unggah File</label>
                                <x-base.form-input type="file" name="file" class="form-control mt-3"/>
                            </div>
                        </div>
                        <div class="rounded-[0.6rem] border border-slate-200/60 p-5 dark:border-darkmode-400 mt-5">
                            <div class="flex items-center border-b border-slate-200/60 pb-5 text-[0.94rem] font-medium dark:border-darkmode-400">Objectives</div>
                            <div class="mt-5">
                                <label class="font-medium">Organizational Objectives</label>
                                <x-base.form-input name="objectives[organizational]" class="form-control mt-3"/>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">Leading Indicator</label>
                                <x-base.form-input name="objectives[leading_indicator]" class="form-control mt-3"/>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">User Outcomes</label>
                                <x-base.form-input name="objectives[user_outcomes]" class="form-control mt-3"/>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">Model Properties</label>
                                <x-base.form-input name="objectives[model_properties]" class="form-control mt-3"/>
                            </div>
                        </div>
                        <div class="rounded-[0.6rem] border border-slate-200/60 p-5 dark:border-darkmode-400 mt-5">
                            <div class="flex items-center border-b border-slate-200/60 pb-5 text-[0.94rem] font-medium dark:border-darkmode-400">Intelligence Experience</div>
                            <div class="mt-5">
                                <label class="font-medium">Penyajian Kecerdasan</label>
                                <x-base.form-input name="experience[penyajian]" class="form-control mt-3"/>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">Fungsi Realisasi Objectives</label>
                                <x-base.form-input name="experience[fungsi]" class="form-control mt-3"/>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">Minimisasi Kesalahan Perangkat Lunak</label>
                                <x-base.form-input name="experience[minimisasi_kesalahan]" class="form-control mt-3"/>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">Pengumpulan Data untuk Perbaikan</label>
                                <x-base.form-input name="experience[pengumpulan_data]" class="form-control mt-3"/>
                            </div>
                        </div>
                        <div class="rounded-[0.6rem] border border-slate-200/60 p-5 dark:border-darkmode-400 mt-5">
                            <div class="flex items-center border-b border-slate-200/60 pb-5 text-[0.94rem] font-medium dark:border-darkmode-400">Intelligence Implementation</div>
                            <div class="mt-5">
                                <label class="font-medium">Proses Bisnis Perangkat Lunak</label>
                                <x-base.form-input name="implementation[proses_bisnis]" class="form-control mt-3"/>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">Teknologi yang Digunakan</label>
                                <x-base.form-input name="implementation[teknologi]" class="form-control mt-3"/>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">Identifikasi Proses Cerdas</label>
                                <x-base.form-input name="implementation[proses_cerdas]" class="form-control mt-3"/>
                            </div>
                        </div>
                        <div class="rounded-[0.6rem] border border-slate-200/60 p-5 dark:border-darkmode-400 mt-5">
                            <div class="flex items-center border-b border-slate-200/60 pb-5 text-[0.94rem] font-medium dark:border-darkmode-400">Batasan Pengembangan</div>
                            <div class="mt-5">
                                <label class="font-medium">Batasan Pengembangan Modul</label>
                                <x-base.form-input name="batasan[batasan_pengembangan]" class="form-control mt-3"/>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">Status Realisasi Modul</label>
                                <x-base.form-input name="batasan[status_realisasi]" class="form-control mt-3"/>
                            </div>
                        </div>
                        <div class="rounded-[0.6rem] border border-slate-200/60 p-5 dark:border-darkmode-400 mt-5">
                            <div class="flex items-center border-b border-slate-200/60 pb-5 text-[0.94rem] font-medium dark:border-darkmode-400">Perencanaan Implementasi</div>
                            <div class="mt-5">
                                <label class="font-medium">Pelaksanaan Deployment</label>
                                <x-base.form-input name="perencanaan[deployment]" class="form-control mt-3"/>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">Pemeliharaan Perangkat Lunak</label>
                                <x-base.form-input name="perencanaan[pemeliharaan]" class="form-control mt-3"/>
                            </div>
                            <div class="mt-5">
                                <label class="font-medium">Pelaksana Operasi Perangkat Lunak</label>
                                <x-base.form-input name="perencanaan[pelaksana_operasi]" class="form-control mt-3"/>
                            </div>
                        </div>
                    </div>
                    <div class="flex flex-col justify-end gap-5 mt-8 md:flex-row">
                        <x-base.button class="inline-flex items-center rounded-[0.5rem] border-red-300/80 bg-red-500/80 text-white py-2.5 px-6 min-w-[8rem]" variant="outline-danger" onclick="window.history.back()">
                            <x-base.lucide class="mr-2 h-4 w-4 stroke-[1.3]" icon="X"/> Cancel
                        </x-base.button>
                        <x-base.button class="inline-flex items-center rounded-[0.5rem] py-2.5 px-6 min-w-[8rem]" variant="primary" id="save-button">
                            <x-base.lucide class="mr-2 h-4 w-4 stroke-[1.3]" icon="PenLine"/> Save
                        </x-base.button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@pushOnce('scripts')
    @vite('resources/js/components/notification.js')
@endPushOnce

@pushOnce('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const form = document.getElementById('createPekerjaanForm');
            const saveButton = document.getElementById('save-button');

            saveButton.addEventListener('click', async function (event) {
                event.preventDefault();

                try {
                    const response = await fetch(form.action, {
                        method: 'POST',
                        body: new FormData(form),
                    });

                    const data = await response.json();
                    showNotification(data.status, data.message);

                    if (data.status === 'success') {
                        setTimeout(() => {
                            window.location.replace(data.redirect);
                        }, 1500);
                    }
                } catch (error) {
                    console.error('Error:', error);
                    showNotification('error', 'Error submitting form.');
                }
            });
        });
    </script>
@endPushOnce
