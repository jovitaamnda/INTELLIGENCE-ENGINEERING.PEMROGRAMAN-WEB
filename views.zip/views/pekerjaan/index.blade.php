@extends('../themes/' . $activeTheme)

@section('subcontent')
    @include('partials.notification')

    <div class="grid grid-cols-12 gap-6 gap-y-10">
        <div class="col-span-12">
            <div class="flex flex-col gap-y-3 md:flex-row md:items-center md:justify-between">
                <div class="text-base font-medium group-[.mode--light]:text-white">Daftar Pekerjaan</div>

                {{-- Button Group --}}
                <div class="flex flex-wrap gap-x-3 gap-y-2 md:flex-nowrap md:ml-auto md:justify-end">
                    {{-- Delete Button with Modal Trigger --}}
                    <x-base.button id="deleteModalButton" variant="outline-danger" data-tw-toggle="modal" data-tw-target="#deleteModal" disabled>
                        <x-base.lucide icon="Trash" class="mr-2 h-4 w-4 stroke-[1.3]" /> Delete
                    </x-base.button>

                    {{-- Request Review Button with Modal Trigger --}}
                    <x-base.button id="requestReviewModalButton" variant="outline-primary" data-tw-toggle="modal" data-tw-target="#requestReviewModal" disabled>
                        <x-base.lucide icon="Send" class="mr-2 h-4 w-4 stroke-[1.3]" /> Request Review
                    </x-base.button>

                    {{-- Add Data Button --}}
                    <a href="{{ route('pekerjaan.create') }}">
                        <x-base.button variant="primary">
                            <x-base.lucide icon="PlusCircle" class="mr-2 h-4 w-4 stroke-[1.3]" /> Tambah Data
                        </x-base.button>
                    </a>
                </div>
            </div>

            {{-- Delete Modal --}}
            <x-base.dialog id="deleteModal">
                <x-base.dialog.panel>
                    <x-base.dialog.title>Delete Target</x-base.dialog.title>
                    <x-base.dialog.description>Are you sure you want to delete this target?</x-base.dialog.description>
                    <x-base.dialog.footer>
                        <x-base.button variant="outline-secondary" data-tw-dismiss="modal">Cancel</x-base.button>
                        <x-base.button variant="danger" id="deleteButton" data-tw-dismiss="modal">Delete</x-base.button>
                    </x-base.dialog.footer>
                </x-base.dialog.panel>
            </x-base.dialog>

            {{-- Request Review Modal --}}
            <x-base.dialog id="requestReviewModal">
                <x-base.dialog.panel>
                    <x-base.dialog.title>Request Review</x-base.dialog.title>
                    <x-base.dialog.description>Are you sure you want to request a review for this task?</x-base.dialog.description>
                    <x-base.dialog.footer>
                        <x-base.button variant="outline-secondary" data-tw-dismiss="modal">Cancel</x-base.button>
                        <x-base.button variant="primary" id="requestReviewButton" data-tw-dismiss="modal">Request Review</x-base.button>
                    </x-base.dialog.footer>
                </x-base.dialog.panel>
            </x-base.dialog>

            {{-- Filter Form and Table --}}
            <div class="mt-3.5 flex flex-col gap-8">
                <div class="box box--stacked flex flex-col">
                    <div class="flex flex-col gap-y-2 p-5 xl:flex-row xl:items-center">
                        <form class="flex flex-col gap-x-5 gap-y-2 rounded-[0.6rem] border border-dashed border-slate-300/80 p-4 sm:p-5 xl:flex-row xl:border-0 xl:p-0" id="tabulator-html-filter-form">
                            <x-base.form-inline class="flex-col items-start gap-y-2 xl:flex-row xl:items-center">
                                <x-base.form-label class="mr-3 whitespace-nowrap">Search by</x-base.form-label>
                                <x-base.form-select id="tabulator-html-filter-field">
                                    <option value="nama_pekerjaan">Nama</option>
                                    <option value="deskripsi_pekerjaan">Deskripsi</option>
                                    <option value="id_tugas">ID Tugas</option>
                                    <option value="tanggal_mulai">Tanggal Mulai</option>
                                    <option value="tanggal_selesai">Tanggal Selesai</option>
                                    <option value="status_pekerjaan">Status Pekerjaan</option>
                                </x-base.form-select>
                            </x-base.form-inline>
                            <x-base.form-inline class="flex-col items-start gap-y-2 xl:flex-row xl:items-center">
                                <x-base.form-label class="mr-3 whitespace-nowrap">Type</x-base.form-label>
                                <x-base.form-select id="tabulator-html-filter-type" disabled>
                                    <option value="like">like</option>
                                </x-base.form-select>
                            </x-base.form-inline>
                            <x-base.form-inline class="flex-col items-start gap-y-2 xl:flex-row xl:items-center">
                                <x-base.form-label class="mr-3 whitespace-nowrap">Keywords</x-base.form-label>
                                <x-base.form-input type="text" id="tabulator-html-filter-value" placeholder="Search..." />
                            </x-base.form-inline>
                            <div class="mt-2 flex flex-col gap-2 sm:flex-row xl:mt-0">
                                <x-base.button class="w-full border-primary/20 bg-primary/5 sm:w-auto" id="tabulator-html-filter-go" type="button" variant="outline-primary">Search</x-base.button>
                                <x-base.button class="w-full bg-slate-50/50 sm:w-auto" id="tabulator-html-filter-reset" type="button" variant="outline-secondary">Reset</x-base.button>
                            </div>
                        </form>
                        <div class="mt-3 flex flex-col gap-x-3 gap-y-2 sm:flex-row xl:ml-auto xl:mt-0">
                            <x-base.button id="tabulator-print" variant="outline-secondary">
                                <x-base.lucide class="mr-2 h-4 w-4 stroke-[1.3]" icon="Printer" /> Print
                            </x-base.button>
                            <x-base.menu class="sm:ml-auto xl:ml-0">
                                <x-base.menu.button as="x-base.button" variant="outline-secondary">
                                    <x-base.lucide class="mr-2 h-4 w-4 stroke-[1.3]" icon="FileCheck2" /> Export
                                    <x-base.lucide class="ml-2 h-4 w-4 stroke-[1.3]" icon="ChevronDown" />
                                </x-base.menu.button>
                                <x-base.menu.items class="w-40">
                                    @foreach(['csv', 'json', 'xlsx', 'html'] as $format)
                                        <x-base.menu.item id="tabulator-export-{{ $format }}">
                                            <x-base.lucide class="mr-2 h-4 w-4" icon="FileCheck2" /> Export {{ strtoupper($format) }}
                                        </x-base.menu.item>
                                    @endforeach
                                </x-base.menu.items>
                            </x-base.menu>
                        </div>
                    </div>
                    <div class="pb-5">
                        <div class="scrollbar-hidden overflow-x-auto">
                            <input type="hidden" id="auth_token" value="{{ $token }}">
                            <div id="tabulator"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@pushOnce('styles')
    @vite('resources/css/vendors/tabulator.css')
@endPushOnce

@pushOnce('vendors')
    @vite('resources/js/vendors/tabulator.js')
    @vite('resources/js/vendors/lucide.js')
    @vite('resources/js/vendors/lodash.js')
    @vite('resources/js/vendors/xlsx.js')
@endPushOnce

@pushOnce('scripts')
    @vite('resources/js/components/notification.js')
    @vite('resources/js/pekerjaan/tabulator.js')
@endPushOnce
