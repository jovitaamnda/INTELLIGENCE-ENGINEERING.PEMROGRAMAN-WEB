{{-- Notifications --}}
<x-base.notification id="success-notification-content">
    <x-base.lucide class="text-success mr-2 h-6 w-6" icon="CheckCircle"/>
    <div class="ml-4 mr-4">
        <div class="font-medium" id="success-notification-title">Success!</div>
        <div class="mt-1 text-slate-500" id="success-notification-message">Operation completed successfully.</div>
    </div>
</x-base.notification>

<x-base.notification id="error-notification-content" class="hidden">
    <x-base.lucide class="text-danger mr-2 h-6 w-6" icon="XCircle"/>
    <div class="ml-4 mr-4">
        <div class="font-medium" id="error-notification-title">Error!</div>
        <div class="mt-1 text-slate-500" id="error-notification-message">An error has occurred.</div>
    </div>
</x-base.notification>
