@extends('../themes/' . $activeTheme)

@section('subcontent')
    @include('partials.notification')
    <div class="grid grid-cols-12 gap-6 gap-y-10">
        <div class="col-span-12 sm:col-span-10 sm:col-start-2">
            <div class="flex flex-col gap-3 md:h-10 md:flex-row md:items-center">
                <div class="text-base font-medium">Detail Proyek</div>
            </div>
            <div class="mt-5">
                <div class="flex flex-col p-5 box box--stacked">
                    <div class="rounded-[0.6rem] border border-slate-200/60 p-5 dark:border-darkmode-400">
                        <div class="flex items-center border-b border-slate-200/60 pb-5 text-[0.94rem] font-medium dark:border-darkmode-400">
                            Informasi Proyek
                        </div>
                        <div class="mt-5">
                            <label class="font-medium">Nama Proyek</label>
                            <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                                {{ $tugas->nama_tugas }}
                            </div>
                        </div>
                        <div class="mt-5">
                            <label class="font-medium">Deskripsi Proyek</label>
                            <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                                {{ $tugas->deskripsi_tugas }}
                            </div>
                        </div>
                        <div class="mt-5">
                            <label class="font-medium">Prioritas Proyek</label>
                            <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                                {{ $tugas->prioritas_tugas }}
                            </div>
                        </div>
                        <div class="mt-5">
                            <label class="font-medium">Status Proyek</label>
                            <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                                {{ $tugas->status_tugas }}
                            </div>
                        </div>
                        <div class="mt-5">
                            <label class="font-medium">Tanggal Mulai</label>
                            <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                                {{ $tugas->tanggal_mulai }}
                            </div>
                        </div>
                        <div class="mt-5">
                            <label class="font-medium">Batas Waktu</label>
                            <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                                {{ $tugas->deadline_tugas }}
                            </div>
                        </div>
                        <div class="mt-5">
                            <label class="font-medium">Tanggal Dibuat</label>
                            <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                                {{ $tugas->created_at }}
                            </div>
                        </div>
                        <div class="mt-5">
                            <label class="font-medium">Tanggal Diperbarui</label>
                            <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                                {{ $tugas->updated_at }}
                            </div>
                        </div>
                    </div>

                    <div class="rounded-[0.6rem] border border-slate-200/60 p-5 dark:border-darkmode-400 mt-5">
                        <div class="flex items-center border-b border-slate-200/60 pb-5 text-[0.94rem] font-medium dark:border-darkmode-400">
                            Informasi Proyek
                        </div>
                        <div class="mt-5">
                            <label class="font-medium">Nama Proyek</label>
                            <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                                {{ $tugas->nama_proyek }}
                            </div>
                        </div>
                        <div class="mt-5">
                            <label class="font-medium">ID Proyek</label>
                            <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                                {{ $tugas->id_proyek }}
                            </div>
                        </div>
                        <div class="mt-5">
                            <label class="font-medium">Penanggung Jawab</label>
                            <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                                {{ $tugas->penanggung_jawab }}
                            </div>
                        </div>
                    </div>

                    <div class="rounded-[0.6rem] border border-slate-200/60 p-5 dark:border-darkmode-400 mt-5">
                        <div class="flex items-center border-b border-slate-200/60 pb-5 text-[0.94rem] font-medium dark:border-darkmode-400">
                            Tim Pelaksana
                        </div>
                        <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                            @foreach($tugas->tim_pelaksana as $anggota)
                                <div>{{ $anggota }}</div>
                            @endforeach
                        </div>
                    </div>

                    <div class="rounded-[0.6rem] border border-slate-200/60 p-5 dark:border-darkmode-400 mt-5">
                        <div class="flex items-center border-b border-slate-200/60 pb-5 text-[0.94rem] font-medium dark:border-darkmode-400">
                            Detail Analisis
                        </div>
                        <div class="mt-5">
                            <label class="font-medium">Sumber Data</label>
                            <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                                {{ $tugas->sumber_data }}
                            </div>
                        </div>
                        <div class="mt-5">
                            <label class="font-medium">Tujuan Analisis</label>
                            <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                                {{ $tugas->tujuan_analisis }}
                            </div>
                        </div>
                        <div class="mt-5">
                            <label class="font-medium">Metode Analisis</label>
                            <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                                {{ $tugas->metode_analisis }}
                            </div>
                        </div>
                        <div class="mt-5">
                            <label class="font-medium">Alat Analisis</label>
                            <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                                {{ $tugas->alat_analisis }}
                            </div>
                        </div>
                        <div class="mt-5">
                            <label class="font-medium">Catatan Tambahan</label>
                            <div class="bg-gray-100 rounded border border-gray-300 dark:border-darkmode-700 dark:bg-darkmode-800 dark:text-white p-2 mt-3">
                                {{ $tugas->catatan_tambahan }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@pushOnce('scripts')
    @vite('resources/js/components/notification.js')
@endPushOnce
