@extends('../themes/' . $activeTheme)

@section('subcontent')
    @include('partials.notification')

    <div class="grid grid-cols-12 gap-6 gap-y-10">
        <div class="col-span-12">
            <div class="flex flex-col gap-y-3 md:flex-row md:items-center md:justify-between">
                <div class="text-base font-medium group-[.mode--light]:text-white">Daftar Proyek</div>
            </div>

            {{-- Filter Form and Table --}}
            <div class="mt-5 flex flex-col gap-8">
                <div class="box box--stacked flex flex-col">
                    <div class="flex flex-col gap-y-2 p-5 xl:flex-row xl:items-center">
                        <form class="flex flex-col gap-x-5 gap-y-2 rounded-[0.6rem] border border-dashed border-slate-300/80 p-4 sm:p-5 xl:flex-row xl:border-0 xl:p-0" id="tabulator-html-filter-form">
                            <x-base.form-inline class="flex-col items-start gap-y-2 xl:flex-row xl:items-center">
                                <x-base.form-label class="mr-3 whitespace-nowrap">Search by</x-base.form-label>
                                <x-base.form-select id="tabulator-html-filter-field">
                                    <option value="nama_tugas">Nama</option>
                                    <option value="deskripsi_tugas">Deskripsi</option>
                                    <option value="penanggung_jawab">Penanggung Jawab</option>
                                    <option value="prioritas_tugas">Prioritas</option>
                                    <option value="deadline_tugas">Batas Waktu</option>
                                    <option value="status_tugas">Status</option>
                                </x-base.form-select>
                            </x-base.form-inline>
                            <x-base.form-inline class="flex-col items-start gap-y-2 xl:flex-row xl:items-center">
                                <x-base.form-label class="mr-3 whitespace-nowrap">Type</x-base.form-label>
                                <x-base.form-select id="tabulator-html-filter-type" disabled>
                                    <option value="like">like</option>
                                </x-base.form-select>
                            </x-base.form-inline>
                            <x-base.form-inline class="flex-col items-start gap-y-2 xl:flex-row xl:items-center">
                                <x-base.form-label class="mr-3 whitespace-nowrap">Keywords</x-base.form-label>
                                <x-base.form-input type="text" id="tabulator-html-filter-value" placeholder="Search..." />
                            </x-base.form-inline>
                            <div class="mt-2 flex flex-col gap-2 sm:flex-row xl:mt-0">
                                <x-base.button class="w-full border-primary/20 bg-primary/5 sm:w-auto" id="tabulator-html-filter-go" type="button" variant="outline-primary">Search</x-base.button>
                                <x-base.button class="w-full bg-slate-50/50 sm:w-auto" id="tabulator-html-filter-reset" type="button" variant="outline-secondary">Reset</x-base.button>
                            </div>
                        </form>
                        <div class="mt-3 flex flex-col gap-x-3 gap-y-2 sm:flex-row xl:ml-auto xl:mt-0">
                            <x-base.button id="tabulator-print" variant="outline-secondary">
                                <x-base.lucide class="mr-2 h-4 w-4 stroke-[1.3]" icon="Printer" /> Print
                            </x-base.button>
                            <x-base.menu class="sm:ml-auto xl:ml-0">
                                <x-base.menu.button as="x-base.button" variant="outline-secondary">
                                    <x-base.lucide class="mr-2 h-4 w-4 stroke-[1.3]" icon="FileCheck2" /> Export
                                    <x-base.lucide class="ml-2 h-4 w-4 stroke-[1.3]" icon="ChevronDown" />
                                </x-base.menu.button>
                                <x-base.menu.items class="w-40">
                                    @foreach(['csv', 'json', 'xlsx', 'html'] as $format)
                                        <x-base.menu.item id="tabulator-export-{{ $format }}">
                                            <x-base.lucide class="mr-2 h-4 w-4" icon="FileCheck2" /> Export {{ strtoupper($format) }}
                                        </x-base.menu.item>
                                    @endforeach
                                </x-base.menu.items>
                            </x-base.menu>
                        </div>
                    </div>
                    <div class="pb-5">
                        <div class="scrollbar-hidden overflow-x-auto">
                            <input type="hidden" id="auth_token" value="{{ $token }}">
                            <div id="tabulator"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@pushOnce('styles')
    @vite('resources/css/vendors/tabulator.css')
@endPushOnce

@pushOnce('vendors')
    @vite('resources/js/vendors/tabulator.js')
    @vite('resources/js/vendors/lucide.js')
    @vite('resources/js/vendors/lodash.js')
    @vite('resources/js/vendors/xlsx.js')
@endPushOnce

@pushOnce('scripts')
    @vite('resources/js/components/notification.js')
    @vite('resources/js/proyek/tabulator.js')
@endPushOnce
