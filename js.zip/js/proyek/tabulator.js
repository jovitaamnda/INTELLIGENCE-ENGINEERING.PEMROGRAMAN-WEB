document.addEventListener("DOMContentLoaded", function () {
    const tabulatorElement = document.querySelector("#tabulator");

    if (!tabulatorElement) return;

    const tabulator = new Tabulator(tabulatorElement, {
        ajaxURL: "/api/proyek",
        ajaxConfig: {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${$("#auth_token").val()}`
            },
        },

        ajaxResponse: function(url, params, response) {
            return response.data;
        },

        paginationMode: "local",
        filterMode: "local",
        sortMode: "local",
        printAsHtml: true,
        printStyled: true,
        pagination: true,
        paginationSize: 10,
        paginationSizeSelector: [10, 20, 50, 100],
        paginationCounter: "rows",
        layout: "fitColumns",
        placeholder: "No matching records found",
        columns: [
            {
                titleFormatter: "rowSelection",
                formatter: "rowSelection",
                headerSort: false,
                resizable: false,
                print: false,
                download: false,
                vertAlign: "middle",
                maxWidth: 60,
            },
            {
                title: "Nama  Proyek",
                field: "id",
                vertAlign: "middle",
                formatter: "link",
                formatterParams: {
                    labelField: "nama_tugas",
                    urlPrefix: " /proyek/",
                    target: "_blank",
                },
            },
            {
                title: "Deskripsi  Proyek",
                field: "deskripsi_tugas",
                vertAlign: "middle",
                formatter: "textarea",
            },
            {
                title: "Penanggung Jawab",
                field: "penanggung_jawab",
                vertAlign: "middle",
            },
            {
                title: "Prioritas  Proyek",
                field: "prioritas_tugas",
                vertAlign: "middle",
            },
            {
                title: "Batas Waktu",
                field: "deadline_tugas",
                vertAlign: "middle",
            },
            {
                title: "Status Proyek",
                field: "status_tugas",
                vertAlign: "middle",
            }
        ],
    });

    setupEventListeners(tabulator);
});

function setupEventListeners(tabulator) {
    window.addEventListener("resize", () => tabulator.redraw());

    const elements = {
        filterForm: document.getElementById("tabulator-html-filter-form"),
        filterGoButton: document.getElementById("tabulator-html-filter-go"),
        filterResetButton: document.getElementById("tabulator-html-filter-reset"),
        exportCSV: document.getElementById("tabulator-export-csv"),
        exportJSON: document.getElementById("tabulator-export-json"),
        exportXLSX: document.getElementById("tabulator-export-xlsx"),
        exportHTML: document.getElementById("tabulator-export-html"),
        print: document.getElementById("tabulator-print"),
    };

    elements.filterForm.addEventListener("keypress", e => { if (e.key === "Enter") { e.preventDefault(); filterHTMLForm(tabulator); } });
    elements.filterGoButton.addEventListener("click", () => filterHTMLForm(tabulator));
    elements.filterResetButton.addEventListener("click", () => resetFilters(tabulator));
    ["csv", "json", "xlsx", "html"].forEach(type => elements[`export${type.toUpperCase()}`].addEventListener("click", () => tabulator.download(type, `data.${type}`, { sheetName: "Targets", style: true })));
    elements.print.addEventListener("click", () => tabulator.print());
}

function filterHTMLForm(tabulator) {
    const field = document.getElementById("tabulator-html-filter-field").value;
    const type = document.getElementById("tabulator-html-filter-type").value;
    const value = document.getElementById("tabulator-html-filter-value").value;
    tabulator.setFilter(field, type, value);
}

function resetFilters(tabulator) {
    document.getElementById("tabulator-html-filter-field").value = "text_search";
    document.getElementById("tabulator-html-filter-type").value = "like";
    document.getElementById("tabulator-html-filter-value").value = "";
    tabulator.setFilter();
}
