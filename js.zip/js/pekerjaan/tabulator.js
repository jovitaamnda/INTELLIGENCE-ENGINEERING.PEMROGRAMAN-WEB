document.addEventListener("DOMContentLoaded", function () {
    const tabulatorElement = document.querySelector("#tabulator");

    if (!tabulatorElement) return;

    const tabulator = new Tabulator(tabulatorElement, {
        ajaxURL: "/api/pekerjaan",
        ajaxConfig: {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${$("#auth_token").val()}`
            },
        },

        ajaxResponse: function(url, params, response) {
            return response.data;
        },

        paginationMode: "local",
        filterMode: "local",
        sortMode: "local",
        printAsHtml: true,
        printStyled: true,
        pagination: true,
        paginationSize: 10,
        paginationSizeSelector: [10, 20, 50, 100],
        paginationCounter: "rows",
        layout: "fitColumns",
        placeholder: "No matching records found",
        columns: [
            {
                titleFormatter: "rowSelection",
                formatter: "rowSelection",
                headerSort: false,
                resizable: false,
                print: false,
                download: false,
                vertAlign: "middle",
                maxWidth: 60,
            },
            {
                title: "Nama Pekerjaan",
                field: "id",
                vertAlign: "middle",
                formatter: cell => `<a href='/pekerjaan/${cell.getData().id}/edit' class='text-primary hover:underline' style="white-space: normal;">${cell.getData().nama_pekerjaan}</a>`,
            },
            {
                title: "Deskripsi Pekerjaan",
                field: "deskripsi_pekerjaan",
                vertAlign: "middle",
                formatter: "textarea",
            },
            {
                title: "ID Proyek",
                field: "id_tugas",
                vertAlign: "middle",
            },
            {
                title: "Tanggal Mulai",
                field: "tanggal_mulai",
                vertAlign: "middle",
            },
            {
                title: "Tanggal Selesai",
                field: "tanggal_selesai",
                vertAlign: "middle",
            },
            {
                title: "Status Pekerjaan",
                field: "status_pekerjaan",
                vertAlign: "middle",
            }
        ],
        rowSelectionChanged: function(data){
            const requestReviewButton = document.getElementById('requestReviewModalButton');
            requestReviewButton.disabled = data.length === 0;
        }
    });

    setupEventListeners(tabulator);
});

function setupEventListeners(tabulator) {
    window.addEventListener("resize", () => tabulator.redraw());

    const elements = {
        deleteModalButton: document.getElementById("deleteModalButton"),
        requestReviewModalButton: document.getElementById("requestReviewModalButton"),
        deleteButton: document.getElementById("deleteButton"),
        filterForm: document.getElementById("tabulator-html-filter-form"),
        filterGoButton: document.getElementById("tabulator-html-filter-go"),
        filterResetButton: document.getElementById("tabulator-html-filter-reset"),
        exportCSV: document.getElementById("tabulator-export-csv"),
        exportJSON: document.getElementById("tabulator-export-json"),
        exportXLSX: document.getElementById("tabulator-export-xlsx"),
        exportHTML: document.getElementById("tabulator-export-html"),
        print: document.getElementById("tabulator-print"),
        requestReviewButton: document.getElementById("requestReviewButton")
    };

    elements.requestReviewButton.addEventListener("click", () => requestReview(tabulator));
    elements.filterForm.addEventListener("keypress", e => { if (e.key === "Enter") { e.preventDefault(); filterHTMLForm(tabulator); } });
    elements.filterGoButton.addEventListener("click", () => filterHTMLForm(tabulator));
    elements.filterResetButton.addEventListener("click", () => resetFilters(tabulator));
    ["csv", "json", "xlsx", "html"].forEach(type => elements[`export${type.toUpperCase()}`].addEventListener("click", () => tabulator.download(type, `data.${type}`, { sheetName: "Targets", style: true })));
    elements.print.addEventListener("click", () => tabulator.print());

    tabulator.on("rowSelected", function() {
        elements.deleteModalButton.disabled = false;
        elements.requestReviewModalButton.disabled = false;
    });

    tabulator.on("rowDeselected", function() {
        if (!tabulator.getSelectedData().length) {
            elements.deleteModalButton.disabled = true;
            elements.requestReviewModalButton.disabled = true;
        }
    });
}

function filterHTMLForm(tabulator) {
    const field = document.getElementById("tabulator-html-filter-field").value;
    const type = document.getElementById("tabulator-html-filter-type").value;
    const value = document.getElementById("tabulator-html-filter-value").value;
    tabulator.setFilter(field, type, value);
}

function resetFilters(tabulator) {
    document.getElementById("tabulator-html-filter-field").value = "text_search";
    document.getElementById("tabulator-html-filter-type").value = "like";
    document.getElementById("tabulator-html-filter-value").value = "";
    tabulator.setFilter();
}

async function requestReview(tabulator) {
    const selectedData = tabulator.getSelectedData();
    if (!selectedData.length) return showNotification('error', 'No rows selected.');

    const selectedIds = selectedData.map(row => row.id);
    const csrfToken = document.querySelector('meta[name="csrf-token"]').content;

    try {
        const response = await fetch('/pekerjaan/review', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': csrfToken
            },
            body: JSON.stringify({ ids: selectedIds })
        });

        const data = await response.json();
        showNotification(data.success ? 'success' : 'error', data.message);
    } catch (error) {
        console.error('Error:', error);
        showNotification('error', 'Error sending review request.');
    }
}
