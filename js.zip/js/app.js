// Load static files
import.meta.glob(["../images/**"]);
