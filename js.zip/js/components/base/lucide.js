(function () {
    "use strict";

    // Lucide Icons
    createIcons({
        icons,
        "stroke-width": 1.5,
        nameAttr: "data-lucide",
    });
})();
