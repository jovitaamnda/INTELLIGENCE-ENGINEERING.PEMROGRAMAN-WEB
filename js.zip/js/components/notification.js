window.showNotification = function (type, message) {
    const notificationContent = (type === "success" ? $("#success-notification-content") : $("#error-notification-content")).clone();
    notificationContent.removeClass("hidden");
    notificationContent.find(type === "success" ? "#success-notification-message" : "#error-notification-message").text(message);

    Toastify({
        node: notificationContent[0],
        duration: 5000,
        close: true,
        gravity: "top",
        position: "right",
        stopOnFocus: true,
    }).showToast();
}
